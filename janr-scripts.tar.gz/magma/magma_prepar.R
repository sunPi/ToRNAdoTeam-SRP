#creating a matrix 
#matrix(data, nrow, ncol, byrow = FALSE)

library(data.table)
library(dplyr)
library(stringr)
library(stringi)

nalls.table <- fread("nallsEtAl2019_excluding23andMe_allVariants.tab.csv")
dim(nalls.table)
typeof(nalls.table)

df <- data.frame(nalls.table,nrow=length(nalls.table),byrow=TRUE)
df$SNP_ID <- seq.int(nrow(df)))

ex1 <- str_extract(df$SNP, "\\d+")
ex2 <- str_extract(df$SNP, "\\d\\d\\d+")
df$SNP <- ex1
df$Base_pair_position <- ex2

loc.snp <- df[,c("SNP_ID","SNP","Base_pair_position")]
head(loc.snp)

fwrite(loc.snp,file="LOC_SNP.tsv",sep = "\t", col.names=FALSE)

