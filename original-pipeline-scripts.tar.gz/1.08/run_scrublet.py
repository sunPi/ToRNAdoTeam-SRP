import scrublet as scr
import scipy.io
import matplotlib.pyplot as plt
import numpy as np
import os
import sys
from numpy import savetxt

# Input arguments

print ('Number of arguments:', len(sys.argv), 'arguments.')
print ('Argument List:', str(sys.argv))

jobname = '16093812'
inputfolder = '/home/mm961/Documents/res3'
outputfolder = '/home/mm961/Documents/res4'
npcs = 25
exp_db_rate = 0.06
db_thr = 0.25
# 

counts_matrix = scipy.io.mmread(inputfolder + '/' + jobname + '_filtered.mtx').T.tocsc()

print('Counts matrix shape: {} rows, {} columns'.format(counts_matrix.shape[0], counts_matrix.shape[1]))

scrub = scr.Scrublet(counts_matrix, expected_doublet_rate=exp_db_rate)

doublet_scores, predicted_doublets = scrub.scrub_doublets(min_counts=2, 
                                                          min_cells=3, 
                                                          min_gene_variability_pctl=85, 
                                                          n_prin_comps=npcs)

scrub.call_doublets(threshold=db_thr)

# Duplet score for cells
savetxt(outputfolder + '/' + jobname + '_duplets_score.csv', scrub.doublet_scores_obs_, delimiter=',')
# Simulated duplets
savetxt(outputfolder + '/' + jobname + '_sim_duplets_score.csv', scrub.doublet_scores_sim_, delimiter=',')

# UMAP
print('Running UMAP...')
umap = scr.get_umap(scrub.manifold_obs_, n_neighbors=10, min_dist=0.1)
savetxt(outputfolder + '/' + jobname + '_umap_scrublet.csv', umap, delimiter=',')
    

scrub.plot_histogram();

print('Done.')
