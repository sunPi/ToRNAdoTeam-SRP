#!/bin/bash
#PBS -l walltime=30:00:00 
#PBS -l nodes=1:ppn=10
#PBS -l vmem=80g
#PBS -N toRNAdo-clustering-re-analysis-SCANPY
#PBS -o output.txt
#PBS -e error.txt

echo "Started!"
echo "To invoke this shell script, use 'qsub name.sh'"
echo "To monitor use 'qstat'"
echo "To remove a jobe use 'qdel ####', where #### is the number of the job"

cd /scratch/spectre/j/jr429/SRP/jobs/Scanpy
module load python/gcc/3.6.4 

echo "Need to install a few packages before running Scanpy"
conda install seaborn scikit-learn statsmodels numba pytables
conda install -c conda-forge python-igraph leidenalg




