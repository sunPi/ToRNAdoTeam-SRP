import numpy as np
import pandas as pd
import scanpy as sc

sc.settings.verbosity = 3             # verbosity: errors (0), warnings (1), info (2), hints (3)
sc.logging.print_header()
sc.settings.set_figure_params(dpi=80, facecolor='white')

results_file = './output/ipdco_scanpy_results'  # the file that will store the analysis results

#--------------------------------------------- Use this to read in the UMI count matrix

adata = sc.read_10x_mtx(
    '/scratch/spectre/j/jr429/SRP/jobs/geo/IPDCO_hg_midbrain_UMI',  # the directory with the `UMI` file
    var_names='gene_symbols',                # use gene symbols for the variable names (variables-axis index)
    cache=True)                              # write a cache file for faster subsequent reading

adata.var_names_make_unique()  # this is unnecessary if using `var_names='gene_ids'` in `sc.read_10x_mtx`
print("adata")

#--------------------------------------------- Preprocessing
high_frac = sc.pl.highest_expr_genes(adata, n_top=20, )
print(high_frac)

# Basic filtering
sc.pp.filter_cells(adata, min_genes=200)
sc.pp.filter_genes(adata, min_cells=3)

# Assign meta-info about mitochondrial genes

adata.var['mt'] = adata.var_names.str.startswith('MT-')  # annotate the group of mitochondrial genes as 'mt'
sc.pp.calculate_qc_metrics(adata, qc_vars=['mt'], percent_top=None, log1p=False, inplace=True)

# Violin plot to visualise some of the QC methods
sc.pl.violin(adata, ['n_genes_by_counts', 'total_counts', 'pct_counts_mt'],
             jitter=0.4, multi_panel=True)

# Remove cells with to many mitochondrial genes expressed or too many total counts
sc.pl.scatter(adata, x='total_counts', y='pct_counts_mt')
sc.pl.scatter(adata, x='total_counts', y='n_genes_by_counts')

# Actual filtering by slicing AnnData object

adata = adata[adata.obs.n_genes_by_counts < 2500, :]
adata = adata[adata.obs.pct_counts_mt < 5, :]

# Total-count normalize so that counts become comparable among cells
sc.pp.normalize_total(adata, target_sum=1e4)

# Logarithmize the data
sc.pp.log1p(adata)

#---------------------------- Highly variable gene identification

sc.pp.highly_variable_genes(adata, min_mean=0.0125, max_mean=3, min_disp=0.5)
sc.pl.highly_variable_genes(adata)

# Save the state of the AnnData object
adata.raw = adata

# Filtering genes
adata = adata[:, adata.var.highly_variable]

# Regress data
sc.pp.regress_out(adata, ['total_counts', 'pct_counts_mt'])

# Gene scaling
sc.pp.scale(adata, max_value=10)

#---------------------------- PCA Analysis

# Reducing dimensionality
sc.tl.pca(adata, svd_solver='arpack')

# Visualise using scatter plot 
sc.pl.pca(adata, color='CST3')

# Contribution of single PC to total variance of data
sc.pl.pca_variance_ratio(adata, log=True)

# Save the results
adata.write(results_file)
print(adata)

#---------------------------- Computing the neighborhood graph

sc.pp.neighbors(adata, n_neighbors=10, n_pcs=40)

# Graph embedding

#tl.paga(adata)
#pl.paga(adata, plot=False)  # remove `plot=False` if you want to see the coarse-grained graph
#tl.umap(adata, init_pos='paga')

sc.tl.umap(adata)
sc.pl.umap(adata, color=['CST3', 'NKG7', 'PPBP'])

sc.pl.umap(adata, color=['CST3', 'NKG7', 'PPBP'], use_raw=False)

#---------------------------- Cell clustering
#As with Seurat and many other frameworks, we recommend the Leiden graph-clustering method (community detection based on optimizing modularity) by Traag *et al.* (2018). Note that Leiden clustering directly clusters the neighborhood graph of cells, which we already computed in the previous section.

sc.tl.leiden(adata)

sc.pl.umap(adata, color=['leiden', 'CST3', 'NKG7'])

# Save the result
adata.write(results_file)

#----------------------------- Find marker genes
#Let us compute a ranking for the highly differential genes in each cluster. For this, by default, #the .raw attribute of AnnData is used in case it has been initialized before. The simplest and fastest method to do so is the t-test

# Wilcoxon test
sc.tl.rank_genes_groups(adata, 'leiden', method='t-test')
sc.pl.rank_genes_groups(adata, n_genes=25, sharey=False)

sc.settings.verbosity = 2  # reduce the verbosity

#The result of a Wilcoxon rank-sum (Mann-Whitney-U) test is very similar. We recommend using the latter in #publications, see e.g., Sonison & Robinson (2018). You might also consider much more powerful #differential testing packages like MAST, limma, DESeq2 and, for python, the recent diffxpy.

sc.tl.rank_genes_groups(adata, 'leiden', method='wilcoxon')
sc.pl.rank_genes_groups(adata, n_genes=25, sharey=False)

# Save the result
adata.write(results_file)

#As an alternative, let us rank genes using logistic regression. For instance, this has been suggested by #Natranos et al. (2018). The essential difference is that here, we use a multi-variate appraoch whereas #conventional differential tests are uni-variate. Clark et al. (2014) has more details.

# Logistic regression alternative
sc.tl.rank_genes_groups(adata, 'leiden', method='logreg')
sc.pl.rank_genes_groups(adata, n_genes=25, sharey=False)

# Let us also define a list of marker genes for later reference.
marker_genes = ["10616", "11322", "17280", "15549", "16693", "15549", "5456", "10842",
    "1672", "6360"]

# Reload the object that has been save with the Wilcoxon Rank-Sum test result.
adata = sc.read(results_file)

# Show the 10 top ranked genes per cluster 0, 1, …, 7 in a dataframe.
pd.DataFrame(adata.uns['rank_genes_groups']['names']).head(5)

# Get a table with the scores and groups.
result = adata.uns['rank_genes_groups']
groups = result['names'].dtype.names
pd.DataFrame(

# Compare to a single cluster:
sc.tl.rank_genes_groups(adata, 'leiden', groups=['0'], reference='1', method='wilcoxon')
sc.pl.rank_genes_groups(adata, groups=['0'], n_genes=20)

# Vln plot for a more detailed view
sc.pl.rank_genes_groups_violin(adata, groups='0', n_genes=8)

# Reload the object with the computed differential expression (i.e. DE via a comparison with the rest of the groups):

adata = sc.read(results_file)
sc.pl.rank_genes_groups_violin(adata, groups='0', n_genes=8)

# If you want to compare a certain gene across groups, use the following.
sc.pl.violin(adata, ["10616", "11322", "17280"], groupby='leiden')

# Actually mark the cell types.
new_cluster_names = [
    '10616', '11322', '17280', '15549', '16693', '15549', '5456', '10842',
    '1672', '6360']
adata.rename_categories('leiden', new_cluster_names)

# Now that we annotated the cell types, let us visualize the marker genes.
sc.pl.dotplot(adata, marker_genes, groupby='leiden');

# There is also a very compact violin plot.
sc.pl.stacked_violin(adata, marker_genes, groupby='leiden', rotation=90);

# During the course of this analysis, the AnnData accumlated the following annotations:
print(adata)
adata.write(results_file, compression='gzip')  # `compression='gzip'` saves disk space, but slows down writing and subsequent reading

#Get a rough overview of the file using h5ls, which has many options - for more details see here. The file format might still be subject to further optimization in the future. All reading functions will remain backwards-compatible, though.

#If you want to share this file with people who merely want to use it for visualization, a simple way to reduce the file size is by removing the dense scaled and corrected data matrix. The file still contains the raw data used in the visualizations in adata.raw.

adata.raw.to_adata().write('./output/ipdco_scanpy_results')

# If you want to export to “csv”, you have the following options:

# Export single fields of the annotation of observations
# adata.obs[['n_counts', 'louvain_groups']].to_csv(
#     './write/pbmc3k_corrected_louvain_groups.csv')

# Export single columns of the multidimensional annotation
# adata.obsm.to_df()[['X_pca1', 'X_pca2']].to_csv(
#     './write/pbmc3k_corrected_X_pca.csv')

# Or export everything except the data using `.write_csvs`.
# Set `skip_data=False` if you also want to export the data.

adata.write_csvs(results_file[:-5], )

